 Chanters("chanters-video", {
     position: "right",
     position_: function(direction) {
         this.position = direction;
     }
 });