 Chanters("chanters-view", {
     onReady: function() {
         this.visibility = "visible";
     }
 });


 // var video = document.createElement("video")
 // console.log(video);
 // video.src = "~/Downloads/The\ Kapil\ Sharma\ Show\ -\ दी\ कपिल\ शर्मा\ शो-Ep\ -\ 95\ -\ Parineeti\ Chopra\ \&\ Ayushmann\ .mp4";
